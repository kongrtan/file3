using Microsoft.AspNetCore.Mvc;

namespace ApiLoggingSample.Controllers;

[ApiController]
[Route("[controller]")]
public class SampleController : ControllerBase
{
    [HttpGet("hello")]
    public IActionResult Hello()
    {
        return Ok(new { message = "Hello, world!" });
    }

    [HttpPost("echo")]
    public IActionResult Echo([FromBody] object body)
    {
        return Ok(body);
    }
}
