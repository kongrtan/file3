using Serilog;
using Serilog.Context;
using System.Diagnostics;

namespace ApiLoggingSample;

public class ApiLoggingMiddleware
{
    private readonly RequestDelegate _next;

    public ApiLoggingMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task Invoke(HttpContext context)
    {
        var traceId = context.Request.Headers["TracingId"].FirstOrDefault()
                      ?? Guid.NewGuid().ToString("N");

        var sw = Stopwatch.StartNew();

        context.Request.EnableBuffering();
        string requestBody = string.Empty;
        using (var reader = new StreamReader(context.Request.Body, leaveOpen: true))
        {
            requestBody = await reader.ReadToEndAsync();
            context.Request.Body.Position = 0;
        }

        var originalBody = context.Response.Body;
        await using var memStream = new MemoryStream();
        context.Response.Body = memStream;

        using (LogContext.PushProperty("trace_id", traceId))
        {
            try
            {
                await _next(context);

                sw.Stop();
                memStream.Position = 0;
                var responseBody = await new StreamReader(memStream).ReadToEndAsync();
                memStream.Position = 0;
                await memStream.CopyToAsync(originalBody);

                Log.ForContext("trace_id", traceId)
                   .ForContext("request_data", requestBody)
                   .ForContext("response_data", responseBody)
                   .ForContext("elapsed_ms", sw.ElapsedMilliseconds)
                   .ForContext("created_at", DateTime.UtcNow)
                   .Information("API completed");
            }
            catch (Exception ex)
            {
                sw.Stop();

                Log.ForContext("trace_id", traceId)
                   .ForContext("request_data", requestBody)
                   .ForContext("response_data", (string?)null)
                   .ForContext("elapsed_ms", sw.ElapsedMilliseconds)
                   .ForContext("created_at", DateTime.UtcNow)
                   .Error(ex, "API failed");

                throw;
            }
            finally
            {
                context.Response.Body = originalBody;
            }
        }
    }
}
