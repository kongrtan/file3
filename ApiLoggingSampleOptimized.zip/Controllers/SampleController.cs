using Microsoft.AspNetCore.Mvc;

namespace ApiLoggingSampleOptimized.Controllers;

[ApiController]
[Route("[controller]")]
public class SampleController : ControllerBase
{
    [HttpGet("hello")]
    public IActionResult Hello()
    {
        return Ok(new { message = "Hello, optimized logging!" });
    }

    [HttpPost("echo")]
    public IActionResult Echo([FromBody] object body)
    {
        return Ok(body);
    }
}
